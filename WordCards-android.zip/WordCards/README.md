# Flincy — Android-проект

Полностью офлайн: в приложении нет разрешения на интернет. Данные хранятся на телефоне.

## Как получить APK (без Android Studio)
1. Создайте аккаунт на github.com и новый репозиторий.
2. Загрузите в него ВСЕ файлы этого проекта, включая скрытую папку `.github`
   (если браузер её не берёт: Add file -> Create new file, имя
   `.github/workflows/build.yml`, вставьте содержимое файла оттуда).
3. Вкладка Actions -> Build APK -> Run workflow. Через 3-5 минут откройте
   завершённый запуск и скачайте `WordCards-apk` внизу страницы (внутри zip лежит app-debug.apk).
4. Распакуйте, перенесите APK на телефон, откройте и разрешите
   установку из этого источника.

## Имя и иконка
- Имя: `app/src/main/res/values/strings.xml` (сейчас Flincy).
- Иконка: `res/mipmap-xxxhdpi/ic_launcher_foreground.png`.

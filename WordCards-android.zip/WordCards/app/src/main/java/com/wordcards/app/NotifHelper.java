package com.wordcards.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

import java.util.Calendar;
import java.util.Random;

public class NotifHelper {
    static final String CHANNEL = "flincy_daily";

    static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences("flincy_notif", Context.MODE_PRIVATE);
    }

    static void ensureChannel(Context c) {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(new NotificationChannel(
                        CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_DEFAULT));
            }
        }
    }

    static PendingIntent alarmIntent(Context c) {
        Intent i = new Intent(c, NotifReceiver.class);
        return PendingIntent.getBroadcast(c, 100, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    /** Ставит (или снимает) ежедневный будильник по сохранённым настройкам. */
    static void schedule(Context c) {
        SharedPreferences p = prefs(c);
        AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = alarmIntent(c);
        am.cancel(pi);
        if (!p.getBoolean("on", false)) return;
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, p.getInt("h", 20));
        t.set(Calendar.MINUTE, p.getInt("m", 0));
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        if (t.getTimeInMillis() <= System.currentTimeMillis()) t.add(Calendar.DAY_OF_YEAR, 1);
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, t.getTimeInMillis(),
                AlarmManager.INTERVAL_DAY, pi);
    }

    static String wordForm(int n) {
        int a = n % 10, b = n % 100;
        if (a == 1 && b != 11) return "слово";
        if (a >= 2 && a <= 4 && (b < 10 || b >= 20)) return "слова";
        return "слов";
    }

    static void show(Context c) {
        ensureChannel(c);
        SharedPreferences p = prefs(c);
        int due = p.getInt("due", 0);

        java.util.List<String> pool = new java.util.ArrayList<String>();
        pool.add("Пора повторить слова");
        pool.add("Пара минут, и слова запомнятся лучше");
        pool.add("Не прерывайте серию: зайдите на пару минут");
        pool.add("Короткое занятие сегодня лучше длинного на выходных");
        pool.add("Flincy ждёт вас: освежим слова?");
        if (due > 0) {
            pool.add("Ждёт повторения: " + due + " " + wordForm(due));
            pool.add("Сегодня стоит повторить " + due + " " + wordForm(due));
            pool.add(due + " " + wordForm(due) + " просят повторения");
        }
        Random rnd = new Random();
        int last = p.getInt("last", -1);
        int idx;
        do {
            idx = rnd.nextInt(pool.size());
        } while (idx == last && pool.size() > 1);
        p.edit().putInt("last", idx).apply();

        String[] titles = {"Flincy", "Время учиться", "Слова скучают по вам"};
        String title = titles[rnd.nextInt(titles.length)];

        Intent open = new Intent(c, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, 101, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        Notification n = new Notification.Builder(c, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(title)
                .setContentText(pool.get(idx))
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.notify(1, n);
    }
}

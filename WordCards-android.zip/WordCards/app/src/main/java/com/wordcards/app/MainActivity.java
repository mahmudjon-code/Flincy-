package com.wordcards.app;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> chooserCallback;
    private String pendingJson;
    private TextToSpeech tts;
    private boolean ttsReady = false;
    private static final int PICK = 1;
    private static final int SAVE = 2;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                ttsReady = (status == TextToSpeech.SUCCESS);
            }
        });
        web = new WebView(this);
        web.setBackgroundColor(0xFF0A092D);
        web.setFitsSystemWindows(true);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        // Блокируем любые переходы за пределы приложения
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"file".equals(r.getUrl().getScheme());
            }
        });

        // Выбор фото и файла копии
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (chooserCallback != null) chooserCallback.onReceiveValue(null);
                chooserCallback = cb;
                try {
                    startActivityForResult(p.createIntent(), PICK);
                } catch (Exception e) {
                    chooserCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Сохранение резервной копии файлом (выбор места через системное окно)
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void saveBackup(final String json) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        pendingJson = json;
                        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                        i.addCategory(Intent.CATEGORY_OPENABLE);
                        i.setType("application/json");
                        i.putExtra(Intent.EXTRA_TITLE, "flincy-backup-"
                                + new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date()) + ".json");
                        startActivityForResult(i, SAVE);
                    }
                });
            }
        }, "Android");

        // Озвучка слов встроенным синтезом речи телефона
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void speak(final String text, final String lang, final float rate) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (!ttsReady) {
                            Toast.makeText(MainActivity.this, "Синтез речи ещё не готов. Попробуйте ещё раз", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        int r = tts.setLanguage(Locale.forLanguageTag(lang));
                        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                            Toast.makeText(MainActivity.this, "Нет английского голоса. Установите его в настройках телефона: Синтез речи", Toast.LENGTH_LONG).show();
                            return;
                        }
                        tts.setSpeechRate(rate);
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "flincy");
                    }
                });
            }
        }, "AndroidTTS");

        // Ежедневные напоминания
        web.addJavascriptInterface(new Object() {
            @JavascriptInterface
            public void schedule(boolean on, int h, int m, String days) {
                SharedPreferences.Editor e = NotifHelper.prefs(MainActivity.this).edit();
                e.putBoolean("on", on).putInt("h", h).putInt("m", m).putString("days", days).apply();
                NotifHelper.schedule(MainActivity.this);
            }

            @JavascriptInterface
            public void setDue(int n) {
                NotifHelper.prefs(MainActivity.this).edit().putInt("due", n).apply();
            }

            @JavascriptInterface
            public void test() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                != PackageManager.PERMISSION_GRANTED) {
                            Toast.makeText(MainActivity.this,
                                    "Разрешите уведомления для Flincy в настройках телефона", Toast.LENGTH_LONG).show();
                        }
                        NotifHelper.show(MainActivity.this);
                    }
                });
            }

            @JavascriptInterface
            public void requestPermission() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission("android.permission.POST_NOTIFICATIONS")
                                != PackageManager.PERMISSION_GRANTED) {
                            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 3);
                        }
                    }
                });
            }
        }, "AndroidNotif");

        web.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == PICK && chooserCallback != null) {
            chooserCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            chooserCallback = null;
        } else if (req == SAVE) {
            if (res == RESULT_OK && data != null && data.getData() != null && pendingJson != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    os.write(pendingJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "Копия сохранена", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Не удалось сохранить копию", Toast.LENGTH_LONG).show();
                }
            }
            pendingJson = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        web.evaluateJavascript("window.__back&&window.__back()", v -> {
            if (!"true".equals(v)) finish();
        });
    }
}

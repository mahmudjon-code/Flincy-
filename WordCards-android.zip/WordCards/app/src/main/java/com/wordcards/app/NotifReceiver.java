package com.wordcards.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

public class NotifReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        String days = NotifHelper.prefs(c).getString("days", "1,2,3,4,5,6,7");
        int dow = Calendar.getInstance().get(Calendar.DAY_OF_WEEK); // 1 = воскресенье
        int iso = (dow + 5) % 7 + 1;                                  // 1 = понедельник ... 7 = воскресенье
        if ((("," + days + ",")).contains("," + iso + ",")) {
            NotifHelper.show(c);
        }
    }
}
